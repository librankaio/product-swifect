require("./bootstrap");
require("jquery");
window.jQuery = window.$ = require("jquery");
require("select2");
// require("prismjs");
require("datatables.net-bs4")
