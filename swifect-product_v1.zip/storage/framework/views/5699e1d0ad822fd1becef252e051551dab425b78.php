
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Transaction</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Transaction</a></div>
            <div class="breadcrumb-item"><a class="text-muted">TPOS LIST</a></div>
        </div>
    </div>

    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4>TPOS LIST</h4>
                    </div>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tanggal Dari</label>
                                        <input type="date" class="form-control" name="dtfr">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tanggal Dari</label>
                                        <input type="date" class="form-control" name="dtfr">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary mr-1" type="submit"
                                formaction="<?php echo e(route('mbrgpost')); ?>">Save</button>
                            <button class="btn btn-secondary" type="reset">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm" id="datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">No Trans</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Code Customer</th>
                                        <th scope="col">Edit</th>
                                        <th scope="col">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 0 ?>
                                    <?php $__currentLoopData = $tposhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $tposh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $counter++ ?>
                                    <tr>
                                        <th scope="row"><?php echo e($counter); ?></th>
                                        <td><?php echo e($tposh->no); ?></td>
                                        <td><?php echo e(date("d/m/Y", strtotime($tposh->tdt))); ?></td>
                                        <td><?php echo e($tposh->code_mcust); ?></td>
                                        <td><a href="/transpos/<?php echo e($tposh->id); ?>/edit"
                                                class="btn btn-icon icon-left btn-primary"><i class="far fa-edit">
                                                    Edit</i></a></td>
                                        <td>
                                            <form action="/transpos/delete/<?php echo e($tposh->id); ?>"
                                                id="del-<?php echo e($tposh->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-icon icon-left btn-danger"
                                                    id="del-<?php echo e($tposh->id); ?>" type="submit"
                                                    data-confirm="WARNING!|Do you want to delete <?php echo e($tposh->name); ?> data?"
                                                    data-confirm-yes="submitDel(<?php echo e($tposh->id); ?>)"><i
                                                        class="fa fa-trash">
                                                        Delete</i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('botscripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2({});
    });

    $('#datatable').DataTable({
        // "ordering":false,
        "bInfo" : false
    });

    function submitDel(id){
        $('#del-'+id).submit()
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\swifect-product\resources\views/pages/transaction/tposlist.blade.php ENDPATH**/ ?>