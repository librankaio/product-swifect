<ul class="sidebar-menu">
    <li class="menu-header">MASTER</li>
    <li class="nav-item dropdown">
        <a href="#" class="nav-link has-dropdown"><i class="fas fa-cubes"></i><span>Master Data</span></a>
        <ul class="dropdown-menu">
            <li><a class="nav-link" href="<?php echo e(route('mbrg')); ?>">Master Data Item</a></li>
            <li><a class="nav-link" href="<?php echo e(route('msatuan')); ?>">Master Satuan</a></li>
            <li><a class="nav-link" href="<?php echo e(route('mgrup')); ?>">Master Data Group</a></li>
            
            <li><a class="nav-link" href="<?php echo e(route('mbank')); ?>">Master Bank</a></li>
            
            
            <li><a class="nav-link" href="<?php echo e(route('mcust')); ?>">Master Data Customer</a></li>
            <li><a class="nav-link" href="<?php echo e(route('msupp')); ?>">Master Data Supplier</a></li>
            <li><a class="nav-link" href="<?php echo e(route('mwhse')); ?>">Master Data Lokasi</a></li>
        </ul>
    </li>
    <li class="menu-header">Transaction</li>
    <li class="nav-item dropdown">
        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-exchange-alt"></i>
            <span>Transaction</span></a>
        <ul class="dropdown-menu">
            <li><a class="nav-link disabled" href="<?php echo e(route('tbelibrg')); ?>">Pembelian Barang</a></li>
            <li><a class="nav-link disabled" href="<?php echo e(route('tbelibrglist')); ?>">Pembelian Barang List</a></li>
            <li><a class="nav-link disabled" href="<?php echo e(route('tpengeluaranbrg')); ?>">Penjualan Barang</a></li>
            <li><a class="nav-link disabled" href="<?php echo e(route('tpengeluaranbrglist')); ?>">Penjualan Barang List</a></li>
            <li><a class="nav-link" href="<?php echo e(route('tpos')); ?>">Pos</a></li>
            <li><a class="nav-link" href="<?php echo e(route('tposlist')); ?>">Pos List</a></li>
        </ul>
    </li>
    <li class="menu-header">Reports</li>
    <li class="nav-item dropdown">
        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-chart-bar"></i>
            <span>Reports</span></a>
        <ul class="dropdown-menu">
            <li><a class="nav-link" href="">Default Layout</a></li>
            <li><a class="nav-link" href="layout-transparent.html">Transparent Sidebar</a></li>
            <li><a class="nav-link" href="layout-top-navigation.html">Top Navigation</a></li>
        </ul>
    </li>
    
    

<?php /**PATH D:\applications\swifect-product\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>