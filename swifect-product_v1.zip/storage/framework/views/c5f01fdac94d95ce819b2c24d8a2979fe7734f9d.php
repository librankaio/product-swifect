
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Master Data</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Master Data</a></div>
            <div class="breadcrumb-item"><a class="text-muted">Master Data Item (EDIT)</a></div>
        </div>
    </div>

    <div class="section-body">
        <form action="" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4>Master Data Item (EDIT)</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Kode</label>
                                        <input type="text" name="kode" class="form-control" value="<?php echo e($mitem->code); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Lokasi</label>
                                        <select class="form-control select2" name="lokasi">
                                            <option selected><?php echo e($mitem->code_mwhse); ?></option>
                                            <?php $__currentLoopData = $mwhses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $mwhse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($mwhse->name); ?></option>                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Harga Beli(Rp.)</label>
                                        <input type="text" class="form-control" name="hrgbeli"
                                            value="<?php echo e($mitem->price); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Note</label>
                                        <textarea class="form-control" style="height:50px"
                                            name="note"><?php echo e($mitem->note); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nama</label>
                                        <input type="text" class="form-control" name="nama" value="<?php echo e($mitem->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Satuan</label>
                                        <select class="form-control select2" name="satuan">
                                            <option selected><?php echo e($mitem->code_muom); ?></option>
                                            <?php $__currentLoopData = $muoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $muom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($muom->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Harga Jual(Rp.)</label>
                                        <input type="text" class="form-control" name="hrgjual"
                                            value="<?php echo e($mitem->price2); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Item Group</label>
                                        <select class="form-control select2" name="itemgrp">
                                            <option selected><?php echo e($mitem->code_mgrp); ?></option>
                                            <?php $__currentLoopData = $mgrps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $mgrp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($mgrp->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary mr-1" type="submit"
                                formaction="/masterdatabarang/<?php echo e($mitem->id); ?>">Save</button>
                            <button class="btn btn-secondary" type="reset">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('botscripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2({});
    });

    $('#datatable').DataTable({
        // "ordering":false,
        "bInfo" : false
    });

    function submitDel(id){
        $('#del-'+id).submit()
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\swifect-product\resources\views/pages/master/mdatabrgedit.blade.php ENDPATH**/ ?>